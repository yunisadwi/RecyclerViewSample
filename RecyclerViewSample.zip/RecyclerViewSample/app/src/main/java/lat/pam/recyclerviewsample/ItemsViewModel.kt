package lat.pam.samplerecyclerview
data class ItemsViewModel(val text: String) {}
